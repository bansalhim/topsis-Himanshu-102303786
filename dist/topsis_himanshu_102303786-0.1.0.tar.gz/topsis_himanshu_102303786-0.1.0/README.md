# Topsis-Himanshu-102303786

This Python package implements the TOPSIS method for Multi-Criteria Decision Making.

## Installation

```bash
pip install Topsis-Himanshu-102303786
```
